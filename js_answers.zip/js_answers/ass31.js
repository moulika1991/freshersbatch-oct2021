class Rectangle{
    width=10;
    height=20;
}
var r1=new Rectangle();
var r2=new Rectangle();
console.log(r1.width,r1.height);
console.log(r2.width,r2.height);
r1.width=20;
console.log(r1.width,r1.height);