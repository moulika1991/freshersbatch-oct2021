const obj={
    firstName:"Queany",
    lastName:"Gonsalves"
}
console.log(obj.middleName);
obj.middleName="Carol";
console.log(obj.middleName);
