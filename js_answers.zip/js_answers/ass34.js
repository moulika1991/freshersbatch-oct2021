const obj={
    firstName:"Queany",
    lastName:"Gonsalves"
}
console.log(obj.firstName);
console.log(obj.lastName);
obj.lastName="Kevin";
console.log(obj.firstName);
console.log(obj.lastName);
