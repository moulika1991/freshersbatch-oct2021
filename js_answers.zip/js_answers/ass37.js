const jsonstr='{"firstName":"Queany", "lastName":"Gonsalves"}';
const obj=JSON.parse(jsonstr);
console.log(obj.firstName,obj.lastName)