const obj={
    firstName:"Queany",
    lastName:"Gonsalves"
}
let v1=eval("obj");
console.log(v1);
console.log(obj.firstName,obj.lastName);