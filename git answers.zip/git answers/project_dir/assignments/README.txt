folder contains css,html,javascript assignments
