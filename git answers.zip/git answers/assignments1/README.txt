css assignments, after modification, in master

