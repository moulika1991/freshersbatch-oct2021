<<<<<<< HEAD
contains css,html,javascript files and now for changing at step 31
=======
contains css,html,javascript files , changed now at step 34
>>>>>>> html-assignment
