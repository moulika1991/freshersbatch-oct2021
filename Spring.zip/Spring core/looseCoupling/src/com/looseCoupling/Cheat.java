package com.looseCoupling;

public interface Cheat {
public void cheat();

}
