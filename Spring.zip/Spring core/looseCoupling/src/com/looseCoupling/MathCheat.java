package com.looseCoupling;

public class MathCheat implements Cheat{
	public void cheat()
	{
		System.out.println("math cheating started");
	}

}
