package com.looseCoupling;

public class ScienceCheat implements Cheat{
	
	public void cheat()
	{
		
		System.out.println("science cheating started");
	}

}
