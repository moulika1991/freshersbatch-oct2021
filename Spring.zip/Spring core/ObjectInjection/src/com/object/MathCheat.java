package com.object;

public class MathCheat {

	public void mathCheat()
	{
		System.out.println("math cheating started");
	}
}
