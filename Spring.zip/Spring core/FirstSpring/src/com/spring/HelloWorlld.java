package com.spring;

public class HelloWorlld {

	public void method() {
		System.out.println("helloworld");
	}

}
