package java_ass;

import java.util.Scanner;

public class MainTestStore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s1=new Scanner(System.in);
		System.out.println("enter the Customer name:");
		String name=s1.nextLine();
		System.out.println("enter the Customer Id  :");
		String idno=s1.nextLine();
		System.out.println("enter the Customer balance:");
		double balance=s1.nextDouble();
		
		Customers c1=new Customers(name,idno,balance);
		
		System.out.println("Item1");
		System.out.println("Enter the Item name:");
		s1.nextLine();
		String itemName=s1.nextLine();
		System.out.println("Enter the Item id:");
		String itemno=s1.nextLine();
		System.out.println("Enter the item Quantity :");
		int itemquantity=s1.nextInt();
		System.out.println("Enter the item price");
		double price=s1.nextDouble();
		
		item a1=new item( itemName,itemno,itemquantity,price);
		
		c1.buyItem(a1); 

	}

}
