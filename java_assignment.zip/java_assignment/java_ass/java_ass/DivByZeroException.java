package java_ass;

public class DivByZeroException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
        	int a=30,b=0;
        	int c=a/b;
        	System.out.println(c);
        }
        catch(ArithmeticException e) {
        	System.out.println("divide by zero exception");

	}

}
}
