package java_ass;

public class StringBuffer3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str2 = new StringBuffer("This method returns the reversed object on which it was called");
		System.out.println(str2.reverse());

	}

}
