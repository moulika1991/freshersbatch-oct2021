package java_ass;

import java.util.Scanner;

public class Marks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] marks = new int[3];
	      int i;
	      Scanner sc = new Scanner(System.in);
	     System.out.print("Enter Marks Obtained in 3 Subjects: ");
	      for(i=0; i<3; i++)
	         marks[i] = sc.nextInt();
		  
	      if(marks[0]>60 && marks[1]>60 && marks[2]>60)
	         System.out.println("passed");

	      else if((marks[0]>60 && marks[1]>60) ||(marks[1]>60 && marks[2]>60)||(marks[2]>60 && marks[0]>60))
	         System.out.println("promoted");
	      else if(marks[0]<60 || marks[1]<60 || marks[2]<60)
	         System.out.println("Failed");
	      else
	       System.out.println("done");

	}

}
