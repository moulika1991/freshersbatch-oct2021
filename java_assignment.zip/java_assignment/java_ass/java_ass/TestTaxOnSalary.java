package java_ass;

public class TestTaxOnSalary {
	

}
