package java_ass;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class itemTest {

	@Test
	final void testCustomer() {
		Customers c1=new Customers("shivani","197",3000);
		String expected="shivani";
		String actual=c1.getName();
		assertEquals(expected,actual,"The method getName will print the customer name");
		String expected2nd="197";
		assertEquals("197",c1.getIdno(),"The method getIdno will print the customer id");
		int expectedbal=3000;
		assertEquals(3000,c1.getBalance(),"The method getBalance will print the customer balance");
		
	}
	@Test
	void testItem() {
		item a1=new item( "chocolate","21",2,200.0);
		String expected="chocolate";
		assertEquals("chocolate",a1.getItemName(),"The method getItemName will print the customer balance");
		String expected2nd="21";
		assertEquals("21",a1.getItemno(),"The method getItemno will print the customer balance");
		int expectedqty=2;
		assertEquals(2,a1.getItemquantity(),"The method getItemquantity will print the customer balance");
		double expectedprc=200.0;
		assertEquals(200.0,a1.getPrice(),"The method getprice will print the customer balance");
		
	}
	}


