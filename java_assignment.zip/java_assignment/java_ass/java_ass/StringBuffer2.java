package java_ass;

public class StringBuffer2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer str1 = new StringBuffer("It is used to _ at the specified index position");
		System.out.println(str1.indexOf("_"));
		System.out.println(str1.replace(14,15,"insert text"));

	}

}
