package java_ass;

public class StringLen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello World";
	    System.out.println(str.length());

	}

}
