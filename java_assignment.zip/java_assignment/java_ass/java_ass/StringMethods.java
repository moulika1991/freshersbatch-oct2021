package java_ass;

public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    String str="Java String pool refers to collection of String which are strored in heap memory";
		System.out.println(str.toLowerCase());			//3a
		System.out.println(str.toUpperCase());			//3b
		System.out.println(str.replace('a','$'));		//3c
		System.out.println(str.contains("collection"));		//3d
		System.out.println(str.equals("java string pool refers to collection of strings which are stored in heap memory"));		//3e
		System.out.println(str.equalsIgnoreCase("java string pool refers to collection of strings which are stored in heap memory"));

	}

}
